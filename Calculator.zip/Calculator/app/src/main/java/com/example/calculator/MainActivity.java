package com.example.calculator;

import android.app.Activity;
import android.view.View;

public class MainActivity extends Activity {
    public void allClearAction(View view) {
    }

    public void backSpaceAction(View view) {
    }

    public void operationAction(View view) {
    }

    public void numberAction(View view) {
    }

    public void equalsAction(View view) {
    }
}
